# SmartEngines Bundle Format Specification

Updated: 2026-01-29
Status: partial reconstruction, verified header layout

## 1) File layout (verified)

```
+------------------+-------------------+------------------------+
|   Text header    |   Binary header   |    Encrypted payload   |
|     59 bytes     |     36 bytes      |      variable size     |
+------------------+-------------------+------------------------+
```

### 1.1 Text header (59 bytes)

Format:
```
sebundle<fmtver>~<engine_version>~<hex40><dec2>~
```

- Magic prefix: `sebundle` (8 bytes)
- Format version: decimal digits immediately after `sebundle` (parsed as int, e.g., `1`)
- Delimiter: `~` (0x7e) after format version, after engine version, after token
- Engine version: ASCII string (examples: `2.7.2`, `3.2.0`, `2.6.4`)
- Token: **40 hex chars + 2 decimal digits**
  - First 40 hex chars -> 20 bytes (validated against constant)
  - Last 2 digits -> decimal length `uVar11` (used in payload header parsing)

Example:
```
00000000: 7365 6275 6e64 6c65 317e 322e 372e 327e  sebundle1~2.7.2~
00000010: 3236 3838 6630 3236 6230 6633 3464 6561  2688f026b0f34dea
00000020: 3331 6233 3737 6266 6535 6664 3166 3665  31b377bfe5fd1f6e
00000030: 6366 3262 3938 3438 3130 7e            cf2b984810~
                                          ^^^^ token tail "10" (decimal)
```

### 1.2 Payload header (post-token)

Let `payload` start at the byte after the 3rd `~`.

- `payload[0:0x14]` (20 bytes): `SHA1(text_header)` XOR `key_table[0:0x14]`
- `payload[0x14:0x14+uVar11]`: encrypted mini‑header bytes; decrypt with
  `key_table[0x14:0x14+uVar11]` (XOR) to get a short `~`‑delimited string.
  This contains an environment tag checked against `"se_demo"`.

The remaining payload bytes (offset `0x14 + uVar11`) are XOR‑decrypted with the
same `key_table` (length 0x80), using an offset of `(0x14 + uVar11) & 0x7f`.

## 2) Encryption / obfuscation (current state)

Actual on-disk decoding is handled by `FUN_027dc8e0` (see `DECRYPTION_FUNCTION_ANALYSIS.md`).
Key points:

- The text header is **plaintext**, not XORed.
- A SHA‑1 of the text header is computed (`FUN_027db64c`) and verified against
  `payload[0:0x14] XOR key_table[0:0x14]`.
- `key_table` is a 0x80‑byte constant table loaded from the binary
  (vaddr `0x004909cf` in this build). It is **not** the 20‑byte header key.
- The rest of the payload is XOR‑decrypted with `key_table` (offseted by
  `(0x14+uVar11)`).

## 3) Compression hints

- Zlib/gzip magic offsets found in decrypted outputs appear to be false positives; no successful decompression yet.
- The native library contains Zip-related symbols:
  - `ZipFileLoader`, `ZipArchive`, `ZipEntry`
  - `GetBundleMainFilename`, `InitFromOwnedZipBuffer`, `CreateFromEmbeddedBundle`
- A ZIP signature `PK\x07\x08` was found at offset 20,107,319 in:
  `decrypted_bundles\bundle_international_faces_liveness_last_attempt.bin`
  This suggests ZIP payloads may exist after successful decryption.

## 4) Next targets

- Confirm ZIP or ZSTD layers by locating successful decompress/loader calls in `libjnimultiengine.so`.
- Trace the XOR keystream generator in the 0x1309f00 cluster and map call sites.
- Validate payload offsets across multiple bundles using the fixed header layout.

## Update 2026-01-30 (validated key table)
- Using the key table located in nalysis/libjnimultiengine.so at file offset  x3909cf yields header_sha1_ok=true for all .se assets in extracted_bundles/assets.
- Decrypted mini header (dec_len=10) is ASCII 1~se_demo~.
- Decrypted body begins with ZSTD magic 28 B5 2F FD at offset 0 (frame header).

## Update 2026-01-30 (ZSTD frame header)
- Decrypted payload begins with a ZSTD frame header (magic 28 B5 2F FD). Frame Header Descriptor byte is 0x00 in all tested bundles.
- ZSTD header parsed with: single_segment=0, dict_id_flag=0, fcs_flag=0, window_desc=0x88 (window_size=134217728). See nalysis/zstd_frame_scan.md.
- ZSTD frame checksum flag is 0 and frame_end equals decrypted body length; no extra trailer after the frame.
## Update 2026-01-30 (ZSTD -> TAR contents)
- Decrypted payloads are **ZSTD-compressed TAR archives** (PAX headers). Decompression via python `zstandard` produces tar streams with JSON configs, models, and nested `.tar.zst` assets.
- See `analysis/zstd_decompress_results.md` and `analysis/decompressed_body_inspection.md` for entry listings.
## Update 2026-01-30 (TAR manifests)
- Decompressed TAR streams contain top-level manifest JSONs: `bundle_*.json` for each bundle, plus `smartid.json` (liveness) and `sdr.json` (docengine demo). These were noted in `analysis/tar_manifest_extraction.md` and extracted to `analysis/manifests/`.
## Update 2026-01-30 (manifest keys)
- `smartid.json` and `sdr.json` contain `bundle_filename` fields pointing to the main bundle manifest JSON (e.g., `bundle_international_faces_liveness.json`). See `analysis/manifest_key_summary.md`.
## Update 2026-01-30 (manifest resource refs)
- Manifest JSONs reference bundle resources via `:/path` strings (virtual paths inside the TAR). Examples: `:/docs/...`, `:/smartid_root_files/...`, `:/mrz-data/...`.
- These refs likely drive loader resolution once TAR entries are indexed.
- See `analysis/manifest_engine_refs.md`.
## Update 2026-01-30 (TAR path resolution)
- Extracted TAR contents and verified that all manifest `:/` references resolve to real files in the TAR (0 missing across all bundles). See `analysis/manifest_path_resolution.md`.
## Update 2026-01-30 (engine configs)
- Engine config JSONs are present in TAR for codeengine and docengine demo bundles; key fields reference `:/` resources (e.g., barcode_reader, doc_preselector, doc_ranker). See `analysis/engine_config_inventory.md` and `analysis/engine_config_summary.md`.
## Update 2026-01-30 (nested model archives)
- TAR payloads contain many nested `.tar.zst` model archives. Sample decompression shows they expand to TARs with `weights/*.pb` and `nn_info.json` (see `analysis/nested_tar_sample.md`).
- Inventory by bundle recorded in `analysis/nested_tar_zst_inventory.md`.
## Update 2026-01-30 (nested model extraction)
- All nested `.tar.zst` archives were decompressed and extracted into `analysis/nested_tar_all/`. Full results in `analysis/nested_tar_all.csv`.
## Update 2026-01-30 (model index)
- Built a full model index (280 models) from nested TAR extractions; each model has `weights/*.pb` and usually `nn_info.json`. See `analysis/model_index.csv` and `analysis/model_index.md`.
- Sample `nn_info.json` metadata extracted in `analysis/nn_info_sample.md`.
## Update 2026-01-30 (recursive resource graph)
- Built recursive manifest graph across JSONs, yielding 5958 refs and 136 model `.tar.zst` refs. See `analysis/resource_graph_recursive.md`.
- One missing JSON ref in codeengine bundle: `recstr/netdata/final/synthetic/eng/755/nn_info.json` (referenced by `recstr/license_plate_rus_recstr.json`), not present in TAR or nested models.
## Update 2026-01-30 (resource graph DOT)
- Generated Graphviz DOT for the recursive resource graph (`analysis/resource_graph.dot`) with edge colors by ref type (json vs tar.zst). See `analysis/resource_graph_note.md`.
